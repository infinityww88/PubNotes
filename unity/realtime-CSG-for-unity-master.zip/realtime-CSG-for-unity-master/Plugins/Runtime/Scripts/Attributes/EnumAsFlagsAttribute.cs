﻿using System;
using UnityEngine;

namespace RealtimeCSG
{
	public class EnumAsFlagsAttribute : PropertyAttribute
	{
		public EnumAsFlagsAttribute() { }
	}
}
