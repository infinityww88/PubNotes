namespace Tripolygon.UModelerX.Runtime.ProBuilderChecker
{
    public class InputSystemChecker
    {
#if INPUTSYSTEM && UNITY_EDITOR
        private static UnityEngine.InputSystem.Pen pen;

        // 0.20.6 버전에서 미작동 처리
        [UnityEditor.InitializeOnLoadMethod]
        private static void InputSystemEnabled()
        {
            string[] versionParts = UnityEngine.Application.unityVersion.Split('.');
            int currentMajor = int.Parse(versionParts[0]);
            if(currentMajor >= 2021)
            {
                Tripolygon.UModelerX.Editor.PenController.Enable();
                Tripolygon.UModelerX.Editor.ExternPackages.ExternLibarary.Add("ReadPenInput", ReadPenInput);
            }
        }

        private static bool ReadPenInput()
        {
            if(pen == null)
            {
                CheckTabletConnection();
            }

            if (pen != null)
            {
                Tripolygon.UModelerX.Editor.PenController.Update(pen.press.ReadValue(), pen.pressure.ReadValue(), pen.position.ReadValue());
            }

            return true;
        }

        private static void CheckTabletConnection()
        {
            var penDevice = UnityEngine.InputSystem.InputSystem.GetDevice("Pen");
            if (penDevice != null)
            {
                pen = (UnityEngine.InputSystem.Pen)penDevice;
            }
        }
#endif
    }
}
